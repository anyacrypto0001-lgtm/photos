# Le Petique Photobooth

A photobooth app in the spirit of Lumabooth, for a Windows laptop. Double-click **LePetique.exe** to run the booth. You can design your own frames, and guests download their photos by scanning a QR code, either **online from any phone on any network** or over the booth's own Wi-Fi.

## What's in the folder
| File | What it is |
|---|---|
| `LePetique.exe` | **Start here.** Runs the booth, saves every session to disk, and serves local-Wi-Fi downloads. |
| `index.html` | The same booth as a single file, as a backup or for an iPad. Online QR downloads work here too; local-Wi-Fi downloads don't. |
| `LePetique Photos\` | Created next to the exe. One folder per day, holding every strip, photo, GIF and boomerang. You can choose a different folder in Settings → Sharing → Saved on this laptop. |

## Starting the booth (Windows)
1. Unzip the folder somewhere permanent, such as `Documents\Le Petique`.
2. Double-click **LePetique.exe**. The booth opens in **its own window**, with no tabs or address bar, like a normal app. Closing the window stops the booth.
   - The window uses Microsoft Edge, which is built into Windows 10 and 11. If Edge isn't there, it uses Google Chrome.
   - The camera is allowed automatically in this window.
   - **"Windows protected your PC"**: click **More info**, then **Run anyway**. You only need to do this once.
   - **Windows Firewall question**: tick **both Private and Public**, then click **Allow**. This is needed for phone downloads over local Wi-Fi.
3. **Full screen:** press **F11**, or tick **Settings → Booth → Open full screen** so it always starts that way. **Kiosk lock** stops guests leaving the booth; staff close it with Alt+F4.
4. **Settings:** tap the small sliders icon at the bottom-right of the start screen. The default PIN is **1234**. You can tap it in or type it with the keyboard's number keys (Backspace deletes, Enter confirms, Esc cancels). Under Settings → Booth, **Open settings with** chooses a PIN (4 to 8 numbers only) or a password (letters, numbers and spaces, at least 4 characters; capitals count). With a password, the lock screen shows a typing box instead of the number pad.

**Where photos are saved:** Settings → Sharing → **Choose folder…** picks any folder on the laptop (a USB stick or a Dropbox/OneDrive folder works too). **Open folder** shows it in File Explorer, and **Default folder** goes back to `LePetique Photos`. Tick **A separate folder for each event** to save into `your folder\event-name\date`. The choice is remembered.

**The camera only runs when it's needed:** it switches on when a guest starts and switches off a few seconds after the photos are taken. The camera light stays on at the start screen only if the start-screen background is the **live camera** (the default). To keep the camera off between guests, go to Customise booth screens → Start → Background and choose a colour, gradient or picture.

Other notes:
- Opening LePetique.exe a second time just opens another booth window.
- There is no black console window any more. Messages go to `LePetique.log`, and window options are kept in `LePetique.json` next to the program.
- **Before the event:** open the booth once with internet, so it saves a copy of the fonts on the laptop.

## Canon direct USB (best quality)
With Canon's EDSDK files in the **`canon`** folder next to `LePetique.exe` (EDSDK 13.21.10; older installs with EDSDK.dll and EdsImage.dll right next to the exe still work), the Camera list has **Canon camera (direct USB, full-resolution photos)**. The booth then shows the camera's live view and, for each photo, fires the real shutter (with autofocus and the camera's flash) and uses the full-size picture. EOS Webcam Utility isn't needed.
- Set the camera to **photo mode** (not movie mode), with **Image quality** set to a JPEG size (RAW only won't work).
- Quit **EOS Utility**, **EOS Webcam Utility**, **dslrBooth** and **Canon Camera Connect**. Only one program can control the camera.
- Turn the camera's **Wi-Fi off** and plug the cable straight into the laptop.
- Each full-size photo is also kept in an `originals` folder inside that day's photos folder.

## Scribble mode (glass panel)
Guests stand behind a clear glass or acrylic panel and draw on it with markers while the camera films them through it, then pose for a final photo.
The final photo prints with Scribble's own design: Edit print templates → **Scribble**. (A booth that used the old Single mode keeps its Single designs: they became Scribble's designs the first time this version opened.)
1. Turn on **Scribble** under Settings → Modes. Set it up under Settings → Modes → Scribble mode:
   - **Scribble time**: how long guests draw (5–180 seconds, 30 by default). The time left shows on screen, with beeps in the last 3 seconds.
   - **Countdown before the final photo** (1–30 seconds, 5 by default).
   - **Flip** (on by default): the camera sees the writing backwards through the glass, so the video and photo are flipped to read the right way round.
   - **Finish early**: guests can tap the screen or press the remote button when they're done.
   - The three on-screen messages.
2. The final photo uses Scribble's own print design (and goes to the printer like a photo).
3. Guests get the photo and the scribble video (MP4) on one QR code. The video plays on the results screen.
- Video size is about 0.3 MB per second, so 30 seconds is about 9 MB. The free Supabase plan allows files up to 50 MB, so keep online scribbles under about 2½ minutes.
- Light the glass from the side, not the front, to avoid reflections; use bright or neon markers.

## Source code
The program's source is in `source\`. To rebuild `LePetique.exe` after changing it, run `source\build.ps1` (it uses the C# compiler built into Windows). The earlier version is kept in `backup\`.
- `source\` holds the parts that would work on any computer: the web server and its routes, saving sessions, the Wi-Fi guest page and analytics. `source\Windows\` holds everything that only works on Windows: the app window and tray icon, printing, DNP drivers and options, the camera check and Canon's EDSDK. A future Mac version would replace only that folder.
- The booth page is built from the `web\` folder: `web\page.html` is the outline, `web\style.css` the look, `web\js\` the app code split by topic (camera, templates, session, printing, delivery, admin, editor, designer...) and `web\vendor\` the MP4 library. `web\build.ps1` joins them into `index.html` (`source\build.ps1` runs it too). **Edit the files in `web\`, not `index.html`**: the next build overwrites it, and refuses if `index.html` looks edited by hand. `index.html` stays one complete file, so it still works on its own.

**Not in the GitHub repository** (kept only on the booth laptop, see `.gitignore`):
- `LePetique.exe`: build it with `powershell -ExecutionPolicy Bypass -File source\build.ps1`.
- The `canon\` folder (Canon's EDSDK, needed for Canon direct USB): get the 64-bit EDSDK from Canon's developer programme and put **all** its library files (EDSDK.dll, EdsImage.dll and the rest) in a folder named `canon` next to `LePetique.exe`. The booth was tested with EDSDK 13.21.10, signed by Canon; the version in use is written to `LePetique.log` at start-up.
- The DNP driver packages in `drivers\`: download them from dnpphoto.com (see `drivers\README.txt`).
- `LePetique Photos\`, `LePetique.log`, `LePetique.json` and `backup\`: guests' photos and the booth's own records.

## Several booths: choose one on the website
Every booth makes its own permanent **Booth ID** the first time it runs (shown in **Settings → Booth → About and updates**), so two booths never get mixed up, even with the same name. **Give each booth its own name** in Settings → Booth. A backup or **Reset settings** never copies or changes a laptop's ID.

A booth appears on the website once it runs **version 2.3.0 or newer** with **Online** delivery (within a minute of being open).

- **Figures for one booth:** on the analytics page, choose it in the **Booth** box at the top. Every tab then shows only that booth. Sessions from before booths had IDs are under **Older records**. Event fees and costs are per event, not per booth.
- **Booths tab:** one card per booth: **Online** or when it was last seen, its version, its event, and whether an update is available.
  - **Update app** (owners): the booth downloads the newest version **while it keeps working**, and the card shows its progress. It **never restarts by itself**: someone presses **Restart booth** on that laptop when it suits them.
  - **Settings** (owners): change its modes, timings, photo extras, printing choices, event name and tagline. Only what you change is sent. The booth applies it when nobody is using it. The **PIN, online details, camera, printers, delivery and Wi-Fi can only be changed on the booth.**
  - **Edit designs:** opens the design editor with that booth already chosen.
  - **Forget:** removes a booth you no longer use (its records and designs stay).
- **Design editor:** choose **All booths** or one booth, then an event. **Save to booth** saves for that booth only.

Instructions wait until the booth is open, online and not in use (start screen, Settings closed). Managers can see the booths and edit designs, but only owners send updates and settings. After a booth first updates to 2.3.0 (with **Update now** on the booth), it can be updated from the website.

## Giving the app to someone
Send them your download page, **`https://yourdomain/app/`** (made by a release, below). It isn't in your website's menu, but anyone with the link can download the app. The download holds only the app: no photos, settings or database details.

Their steps (also shown on the page):
1. Press **Download Le Petique**, right-click the zip, choose **Extract All**, and put it in a new folder, for example on the Desktop (not in *Program Files*).
2. Open **LePetique.exe**. If Windows says *Windows protected your PC*, press **More info → Run anyway**.
3. Allow the camera.
4. Change the PIN (it starts as `1234`) in **Settings → Booth**.

Developers who want the code instead use `git clone` and run `source\build.ps1`.

## Releasing an update
1. Raise `"app"` in `version.json` (for example `2.2.0` → `2.2.1`) and commit. If you changed `analytics.sql`, raise the database number too (the build tells you where) and run the SQL in Supabase.
2. With nothing left uncommitted, run (your booth can stay open):
```powershell
powershell -ExecutionPolicy Bypass -File release.ps1 -Notes "What is new"
```
The first time, it asks for your website's address (kept on this computer only, in `release.local.json`).
3. Upload the whole **`release\app`** folder it made to your `photos` repository, replacing the old `app` folder (**Add file → Upload files**, drag the `app` folder in, **Commit changes**). Old zips can stay or be deleted.

Booths downloaded from your website then show **Update available** within about 30 minutes (or at once with **Check for updates**).

## Updating the booth app
**Settings → Booth → About and updates** shows the version, and whether a newer one is out. A **yellow dot** on the staff settings button means an update is waiting, or online uploads are paused.

- **Update now** gets the new version **while the booth keeps working**. Nothing changes until you press **Restart booth**; the booth then closes and opens again with the new version. Settings, designs and photos stay. The old program is kept as `LePetique.previous.exe`.
- It never updates by itself, and never during a guest's session (you can only press it in Settings). It checks quietly when the booth starts and when you open Settings.
- **Downloaded from your website** (the folder has `update.txt`): the booth reads your website, downloads the new zip, and only uses it if its fingerprint matches what was released. A damaged or half-finished download is thrown away. If it says it couldn't check, the laptop is offline or the website can't be reached.
- **Cloned with Git** (developers): it pulls and builds using the GitHub sign-in already on that computer. A copy with its **own changes** isn't updated; use `git pull`, then `source\build.ps1` (close the booth first, or build with `-OutFile LePetique.next.exe` and swap it in afterwards).
- A copy from before version 2.2.0 that wasn't cloned doesn't check: download it again from your website into a new folder. To keep its settings, use **Settings → Booth → Export everything** first, and **Import backup** in the new one.

**Online uploads paused?** When several booths share one online database, they must match it. If they don't, the booth keeps taking and printing photos, but **sends nothing online**: records, photos and designs wait on the laptop and go up by themselves once the versions match.
- *"The online database needs updating"*: the owner runs the latest `guest-viewer\analytics.sql` in Supabase (SQL Editor, the whole file).
- *"This booth app is older than the online database"*: update the booth (above).

The analytics page, the website editor and the design editor show a similar note if the page you uploaded and the database don't match.

## Canon EOS R100 (or another mirrorless/DSLR camera)
The first time the booth window opens, it asks to use the camera: click **Allow** once and it remembers.

The booth uses the camera's live video. Connect it one of two ways, then choose it in **Settings → Camera**:
- **USB with Canon EOS Webcam Utility** (free from Canon):
  - Quit Canon **EOS Utility** if it is running.
  - Turn the camera's **Wi-Fi off**.
  - Set the camera to **movie mode**.
  - Choose **EOS Webcam Utility** in the camera list.
- **HDMI capture card** (for example Elgato Cam Link): turn on clean HDMI output in the camera menu, then choose the capture card in the list.

**If the R100 doesn't work:**
1. In the booth, open **Settings → Camera**. A small live preview now shows there, with any error message under it.
2. Pick **EOS Webcam Utility** in the Camera list, not "Default". If it isn't in the list, Windows can't see the camera yet; go through the checks below, then tap **Restart camera**.
3. Use the **latest EOS Webcam Utility** from Canon's website. Older versions don't support the R100. Restart the laptop after installing.
4. Quit **EOS Utility** completely (right-click its icon by the clock, then Exit). It locks the camera.
5. On the camera: **Wi-Fi and Bluetooth off**, the dial or switch on **movie mode**, the camera **switched on** with the screen awake.
6. Use the cable that came with the camera, plugged straight into the laptop (no hub), and try another USB port.
7. Close Zoom, Teams, OBS and the Windows Camera app. Only one app can use the camera at a time.
8. Tick **Keep the camera on all the time**. Big cameras are slow to wake up, and this stops the booth turning the camera off between guests.
9. If USB still won't work, use an HDMI capture card. It's the most reliable way, and the R100 has HDMI output.

Then:
- Set **Camera quality** to 1080p, or higher if your capture card supports it.
- If the camera is mounted on its side for portrait framing, set **Camera mounted** (turned right, turned left or upside down). The preview and the photos are then turned upright.
- For long events, set the camera's auto power-off to Disable and use a DC coupler (dummy battery).
- Photos come from the live video (Full HD), which is plenty for 2×6, 4×6 and 5×7 prints.

## DNP printers: DS-RX1HS and other DNP models (prints with no dialog)
**First time**
1. Install the driver: Settings → Printing → **Printer drivers** → **Install** (or **Repair / update**). Windows asks for permission, then installs it. The DNP drivers are in the `drivers` folder next to `LePetique.exe`; the DS-RX1 / DS-RX1HS driver is DNP's Windows 11 driver, version 1.2.3.0.
2. Switch the printer on and plug it in by USB. Windows adds it within a few seconds. Tap **Refresh printers**.
3. In Settings → Printing the booth adds the DNP automatically. Check its card, then tap **Print a test page (4×6)**: the pink frame should touch every edge and the sheet should come out in one piece. Then tap **Print a strip test (two strips)**: it should come out as two separate 2×6 strips, each numbered 1, 2, 3 (the pink bands where the two strips meet are the test frame, not a fault).

**Each printer has its own card** in Settings → Printing:
- **Status** (Ready, Printing, Offline, Needs attention, Stuck job) with the number of waiting jobs, refreshed every few seconds while Settings is open. The booth can't read how much paper or ribbon is left; DNP's printer display shows that.
- **Use this printer** and **Prints these sizes** (4×6, 2×6 strips, 5×7, 6×8, square).
- **Finish**: Luster (glossy) or Matte, set on every print.
- **Print quality**: 300×300 (standard), 300×600 or 600×600 dpi. **The quality you choose also sets how sharp the booth draws the print.** At standard, a 2×6 strip is 600×1800 px and the 4×6 sheet with two strips is 1200×1800. At 300×600 or 600×600, each strip is drawn at 1200×3600 px and the sheet at 2400×3600, so the printer's full 600×3600 dots per strip are used. Designs don't move, the editor tells you the print size, and an overlay made at the bigger size keeps all its detail. Other print sizes (4×6, 5×7…) get the same doubling. GIFs, videos and the print dialog are unchanged.
- **Paper** per size. The booth picks the plain sizes: (6x4) for 4×6 and strips, (5x7), (6x8), (5x5). Check the choices against the DNP media you've loaded.
- **Clear stuck jobs** cancels everything waiting on that printer. **Remove** takes it off the list.
- **Calibration** (fold-out) fixes a printer that prints off-centre:
  1. Tap **Print calibration sheet**. It has a centre cross and millimetre rulers counting in from every edge.
  2. Read how far off it is. When it's centred, opposite edges show the same number, and a fold down the middle runs through the cross.
  3. Set the difference with the three **sliders**: **Move right** and **Move down** (minus moves left / up), in 0.1 mm steps. The **−** and **+** buttons beside each slider nudge it by 0.1 for fine steps. If white lines show at the edges, set **Size** a little above 100%; if the design gets cut off, set it a little below.
  4. Print the sheet again to check. The values apply to everything that printer prints. **Reset** clears them.
- The **size boxes** ("Prints these sizes") sit in two even columns, so they line up.

**The results screen's print choices are all in one place**, at the top of Settings → Printing, under **When a session is done**: **Show a Print button on the results screen** and **Print automatically as the results screen opens**. (Customise booth screens → Results only sets the Print button's label; it points you here for the rest, so nothing is set in two places.) Photo strips and scribble photos can print. GIFs, boomerangs and video messages aren't printed.

**Printer drivers** are listed once per printer: if the drivers folder holds two packages for the same printer (for example the DS-RX1HS one for Windows 11 and the one for Windows 7/8/10), you see one row with the package that suits this computer, and a note about the other.

**2×6 strips:** the booth prints the strip twice on one 4×6 sheet and the DS-RX1 cuts it into two identical strips. You no longer need a second Windows printer. The cut works at any print quality (tested at 300×300 and 300×600 dpi) on the plain 4×6 paper "(6x4)"; never choose an "x 2" paper for strips. The reason it works: the driver stores a 2-inch cut in two places that Windows' own settings conversion never writes (its text list of chosen options and two numbers in its printer-data block), so the booth writes them the same way DNP's Printing Preferences dialog does, and checks first that the driver's layout is the one it knows (DS-RX1 driver 1.2.3.0). If you made a "2inch cut" copy earlier, it's still listed as a strips-only printer; remove it.

**Windows' own saved settings are ignored for DNP printers.** The booth builds every print from the printer's factory settings plus the options on its card, so a "2inch cut" (or paper or quality) saved earlier in Windows → Printing Preferences can no longer change a booth print. Other programs that print to the same printer still use those saved settings.

**Several printers:** tap **Add printer** to add more. Each print goes to a printer that is on and handles that size, skipping any that are offline and preferring the one with the fewest waiting jobs. This works well with two DNPs at a busy event, or a DNP for 4×6 and another for 6×8.

**Paper sizes:** each template's **Paper size** (template editor) decides what its print is: 4×6, two 2×6 strips on a 4×6 sheet, 5×7, 6×8, 5×5, 6×6 or a custom size. Load the DNP media that matches: 4×6 media for 4×6 and strips; 5×7 media for 5×7 and 5×5; 6×8 media for 6×8 and 6×6. **Copies:** set **Copies of each print** in Settings → Printing.

**Other DNP models:** the `drivers` folder can hold several drivers. Put another driver's folder (the one with the `.inf` file) inside `drivers`, tap **Refresh printers**, and it appears in **Printer drivers** with an **Install** button. Cut, finish and quality choices appear for any DNP printer whose driver offers them. See `drivers\README.txt` for what's included.

"Show the print dialog" is still available, for example for a normal office printer.

---

## Designing your prints (template editor)
Open Settings, then **Design → Edit print templates**. The tabs along the top switch between the modes you have switched on (Photo strip, GIF, Boomerang, Scribble and Video message), and each has its own design. (You can rename these modes; see the next section.)

**Use my own design** (strip and scribble): made your strip in Canva or Photoshop? Export it as a **PNG with transparent (see-through) holes** where the photos go, then click **Upload my design…**. The booth picks the matching paper size, lays your design on top and puts a photo in each hole (up to 8). In Canva: use a transparent-background download and leave the photo areas empty. A JPG or a PNG without holes becomes the background instead, and you drag the photo boxes into place. **Undo** reverses it.

**Photo layout** (strip and scribble)
- **Paper size** (its own section at the top of the template panel): choose what this template is and what one print is. Changing it rescales everything on the frame, and a **Sheet preview** under it shows exactly what will print.
  - **Most used:** 4×6 landscape or portrait (one print = one 4×6), **2×6 strips: two per 4×6 sheet** (one print = one 4×6 sheet carrying two identical 2×6 strips, cut down the middle by the printer), 5×7 and 6×8 landscape or portrait.
  - **More:** 5×5 and 6×6 square, and **Custom size…** (type a width and height in inches, 1 to 12).
  - **Extra options:** for 2×6 strips, tick or untick **Two strips on each 4×6 sheet** (unticked prints one strip on the left half). For a custom size, **Print on** picks 4×6, 5×7 or 6×8; if the design is a different shape from the paper it prints centred with white margins.
  - Guests' digital copies are always a single strip or photo.
- **Arrangements:** one tap gives you a ready-made layout: 4, 3 or 2 stacked; 1 photo; 2 or 3 across; 2×2; 2×3; 3×2; 1 big + 3; 1 big + 2; or Scattered (tilted).
- **Spacing:** sliders for outer margin, space between photos and caption area, and a choice of caption at the top or bottom.
- **Free-form photos:** tap any photo on the frame to move it. Drag the white corner handle to resize it, and hold Shift to keep its shape. You can also:
  - **Tilt** it with the slider.
  - Set an exact shape: square, 4:3, 3:4, 3:2 or 16:9.
  - **Duplicate** or **Delete** it.
  - Change the order photos are taken with **Shoot earlier** and **Shoot later**.
- **+ Photo** adds up to 8 photos per print. The camera crops each shot to the exact shape of its photo box.
- **Photo style:** Plain, Border (with width and colour) or Polaroid (a white card with a deep bottom edge). You can also add rounded corners and a drop shadow.

**On the frame**
- Add **Text**, **Logo**, **QR code**, **Sticker** (any PNG or JPG) or **Line**. Tap any item to select it, then drag to move it. The corner handle resizes it, and the **Tilt** slider rotates it.
- **Text:** choose the font, size, colour, opacity, alignment, and an optional coloured box behind it. Write `{event}`, `{tagline}` or `{date}` and the booth fills them in. Press Enter for a second line.
- **Put behind the photos:** tick this for decorations that should sit under the pictures.
- **QR code:** prints the guest's download QR on the photo. Keep it at least 0.7 inches (about 210 px) wide so phones can scan it.
- **Snapping:** blue guide lines appear when an item lines up with the centre, the edges or another item. Hold Alt to drag freely without snapping.
- **Keyboard:** arrow keys nudge the selected item (Shift moves it further), Delete removes it, Ctrl+Z undoes and Esc deselects.
- **Colour style:** one tap recolours every layout: Classic, Noir, Blush, Garden, Bold or Minimal.
- **Background:** a colour or your own picture. **Overlay PNG:** a transparent PNG drawn over the photos; the editor shows the exact size to design it at.
- **Reset layout** puts the current tab back to the default design.

## Saving designs and letting guests choose
Each mode (strip, GIF, boomerang, scribble, video message) can hold **as many saved designs as you like**. The **Design** box at the top of the template editor lets you:
- **Switch** between saved designs and **rename** them.
- Make a **+ New** design, **Duplicate** the current one (handy for colour variations), or **Delete** it.
- Tick **Guests can choose this design**. When two or more designs are ticked, guests see a **"Choose your design"** screen with a preview of each, right after picking the mode. With only one ticked, that screen is skipped.
- **Export** a design to a file, and **Import** one, to share it with another booth or keep a library of designs between events. Pictures and stickers travel inside the file.

## Live photos and session GIFs
In Settings → Modes, under **Photo extras**:
- **Live photo:** the booth records about a second of motion around each shot, then builds a moving version of the whole print that plays forward and back.
  - There is a short pause after each shot while it records; you can change the on-screen message for that moment.
- **Also make a GIF:** an animated GIF that flips through the session's photos, framed by your GIF design. You can set the seconds per photo.

On the results screen, guests switch between **Photo · GIF · Live photo**, and Save, Share and the QR code follow whichever one is showing.
- **Local Wi-Fi:** one QR code opens a page with all three files.
- **Online:** each file is uploaded, and the QR code changes with the selected view.
- **Booth laptop:** everything is also saved in `LePetique Photos`, for example `..._abc123.jpg`, `..._abc123-gif.mp4` and `..._abc123-live.mp4`.

## Video message (with sound)
Guests record a short video of themselves **with sound**, for example a message for the couple. It's made on the phone-shaped 9:16 screen (1080×1920), with the camera picture in the middle on a blurred copy of itself and the event's **video design** on top (a frame, logo, text, even a QR code). It isn't printed; guests get it by QR code as an MP4 that plays on the results screen with sound.
1. Turn on **Video message** under Settings → Modes, then set it up under **Settings → Modes → Video message**:
   - **Length** (5–60 seconds, 15 by default), with the time left shown on screen. A 60-second message is about 30 MB, so online (free Supabase plan, 50 MB per file) it fits.
   - **Microphone**: choose one, then tap **Test the microphone** and speak: the bar should move.
   - **Finish early**: guests can tap the screen or press the remote button to stop.
   - The two on-screen messages.
2. **The first time**, the booth window asks to use the microphone: choose **Allow**. If you blocked it by mistake, the video is made without sound and the booth tells the guest; allow the microphone for the window and try again.
3. Design the frame in **Edit print templates → Video message** (it works like the GIF and boomerang designs).
- The booth makes a standard H.264 + AAC MP4 that phones and Instagram accept. If a computer's window can't encode AAC, the browser's own recorder is used instead (MP4 or WebM).
- There are no beeps while recording, so the microphone doesn't pick them up. The countdown beeps before it are fine.

## Videos ready for Instagram Stories and other apps
GIF mode, boomerang, live photos, the session GIF and Scribble videos are all saved as **MP4 videos in Story size** (1080×1920, 9:16). The design sits in the middle on a blurred copy of itself, so it fills a phone screen without being cropped.
- Short loops repeat until the video is at least 6 seconds long (never more than 15), so a boomerang doesn't flash past in a Story.
- They are standard MP4 files (H.264, 30 fps) that iPhones, Android phones, Instagram, TikTok and WhatsApp accept. Instagram treats GIFs as still pictures, which is why these are videos now.
- On the online guest page, iPhones get **Save to Photos** and Android phones get **Save to gallery** (see the guest page section).
- On an iPhone, **Save** on the Wi-Fi guest page puts the video in Files → Downloads. From there, tap Share → **Save Video** (to Photos) or Instagram.
- If the booth laptop's browser can't make H.264 videos, the booth falls back to GIFs as before.

## Saved events (one setup per event)
Settings → Event → **Saved events** keeps a separate setup for each event, for example "Tita Gem's Birthday":
- **Each event has its own:** event details, modes and timing, print templates, booth screens (with their pictures and elements) and the filters offered to guests.
- **Shared by all events:** camera, printers and calibration, online and Wi-Fi delivery settings, PIN, your fonts and your filters.
- **New event** starts blank (the standard look) by default. You can choose instead to start as a copy of the event in use (same look and templates, with its own copies of the pictures). Pick an event in **Event in use** to switch. **Delete this event** (tap twice) removes the one in use.
- **Figures:** each event counts its sessions (with a count per mode), prints sent, and its first and last session date. Sessions that were already in the gallery count towards the first event. **Reset this event's figures** clears them.
- **Only what's in use is shown:** the settings for GIF, Boomerang, Scribble, live photo and the session GIF only appear while that mode or extra is switched on, and the template editor and booth-screen fields do the same.
- **Export everything** includes all events and their pictures.

## Backups: export and import everything
Settings → Booth → **Export everything** saves one `.json` file with every setting, design, booth screen, sticker and picture. The photo gallery is not included. **Import backup** on any booth (or after reinstalling) puts it all back; it asks before replacing anything. The file also holds your online-upload key, so keep it private.

## Your own fonts and filters
- **Fonts:** Settings → Event → **Your fonts** → **Upload a font** (.ttf, .otf, .woff, .woff2). Uploaded fonts appear in every font menu (print templates, booth screens, countdown) and are included in **Export everything**. Deleting one switches anything that used it to a plain font.
  - **Slight is the booth's heading font:** an uploaded font named **Slight** is used automatically for the start screen title and for all headings (screen titles, mode names, the results heading). Buttons and small text stay in the clear everyday font. To change it: Customise booth screens → Start → Words → **Title font** for the start title, and → Colours & fonts → **Headings** for the rest (**Same as everyday text** turns Slight off there). Name the file `Slight.otf` (or upload it and check the name in the list). It takes effect the moment you upload it.
  - **Licensed fonts such as Slight stay out of GitHub:** font files (`.otf`, `.ttf`, `.woff`, `.woff2`) are in `.gitignore`. Check the font's licence allows web use before you use the online editor: uploaded fonts travel with your designs to your online photo storage so the editor can show them.
- **Filters:** Settings → **Filters** (its own tab). A live camera picture stays at the top while you scroll the filters and sliders.
  - Tap a filter to try it on the live camera. **Take a test photo** shows what a real photo looks like with it; nothing is saved.
  - **+ New filter (sliders)** makes your own from brightness, contrast, saturation, warmth, tint, fade and black & white.
  - **+ Upload LUT (.cube)** adds a 3D colour LUT from Lightroom, Photoshop or a filter pack. A **Strength** slider blends it with the natural colours.
  - Tick **Offer to guests** to show a filter on the camera screen; it is switched on in the Booth screen editor → Camera. Photos, GIFs, boomerangs and scribble videos all use the filter.

## Booth screen editor
Open Settings, then **Event** and, under **Look**, **Edit booth screens**. It works like the print template editor: the screens are along the top, the booth screen sits in the middle on a chequered stage and updates as you change things, and the settings are on the right. **Add** buttons above the screen (text, picture, logo, mode button, QR code, date / time) put new things on it. The **Layers** list shows everything on the screen, front to back, with **Background** at the bottom: pick one to edit it, or **tap an empty part of the screen** to jump to the background settings (the section flashes so you can see where it is). **Undo** (or Ctrl+Z) steps back through your changes, and **Reset screen** puts the current screen's items and your own elements back how they started (its background and colours stay).

**Move and restyle anything:** on every screen (Start, Choose mode, Choose design, Camera and Results), drag any element (headings, back buttons, each mode card, the camera, filter buttons, start button, photo, QR code, buttons) to wherever you want it.
- Tap an item, or pick it in the **Layers** list, to change its **size**, **font**, **text colour**, **background** and **highlight colour** individually, or to **hide** it.
- **Reset its style** undoes the changes to one item, and **Put everything back in place** returns a screen to its automatic layout.
- While you design, the booth is shown as an exact scaled-down copy of the full screen, so what you place is what guests see.
- **Mode cards** (Choose mode tab): pick a card to change its **width**, **height** and **corner roundness** (from square to pill-shaped). Under **Picture on the card**, choose **Preview of my print design** to show the guest's actual strip on the card, or **My own picture** to upload your own (for example a strip mock-up from Canva). Tick **Picture fills the whole card** for a picture-only card, or leave it off to show the picture above the name with a size slider. Width, height and roundness also work on the back button, start button and the results buttons.
- **Results screen:** the **Photo / GIF / Live photo** switch sits above the QR code as large buttons, so it is always visible. You can move and restyle it like any other item.
- The **Add** buttons put your own things on any screen, and each one has a delete button in the Layers list (or select it and press Delete):
  - words, pictures or your logo;
  - **Mode button**: guests tap it to start that mode straight away, for example a big "Boomerang" button on the start screen. It hides itself while that mode is switched off.
  - **QR code** to any link, such as your Instagram or website;
  - **Date / time**: shows the date, the time, or both, and keeps itself current.
- **Inside a mode card:** select a card on the Choose mode screen and use **Inside the card** to show or hide its icon, name, description and keyboard number, edit its name, description and an extra line (for example "Most popular"), put the icon beside the text, align the text, and set icon and text sizes, spacing, border and shadow. **Use this card's design on all cards** copies it to the others. Keyboard numbers on the cards are off by default.
- **Arranging:**
  - **Layers:** the top of the list is in front. **To front**, **Forward**, **Back** and **To back** change the order.
  - **Lock in place:** stops an element or a built-in item being dragged by mistake.
  - **Snapping:** while dragging, items snap to the screen's centre, near its edges, and to other items' centre lines, with a guide line. Hold Alt to place freely.
  - **Fine moves:** arrow keys move the selected item a little (Shift for bigger steps). **Centre across** and **Centre down** line it up exactly.
- **Colours & fonts** sets fonts by type (everyday text, headings, buttons) and colours for headings and secondary buttons, on top of the quick looks.

| Tab | What you can change |
|---|---|
| **Start** | **Background:** live camera (adjustable blur and darkness), a colour, a gradient or your own picture. **Text:** a small line, the title and a subtitle, each with `{event}`, `{tagline}` and `{date}`. Title font, size and colour, and position on screen (centre, top, bottom or left). Your logo. **Start button:** filled, outline, just text or hidden, with its text, colours and pulse animation. How visible the staff settings button is. |
| **Choose mode** | Heading and back-button text, background, card and icon colours, and whether to show icons, descriptions and keyboard numbers. **Rename each mode** and its description, for example "Classic strip" or "Wedding GIF". |
| **Camera** | **Screen:** background, start-button text, and whether the mode name shows at the top. **Beside the camera:** thumbnails, a live print preview that fills in as photos are taken, or nothing. **Countdown:** seconds, font, colour, size and an animated ring, plus text above the number (e.g. "Strike a pose!") and text as the photo is taken (e.g. "Smile!"). Shot counter text and boomerang messages. **Filters:** which ones guests can pick, or none. **Flash:** on or off and its colour. Sounds. |
| **Results** | Background, heading and messages. QR code size and caption. Show or hide **Print**, **Save**, **Share** and **Go again**, and rename them and **Done**. **Print automatically** after each session, and how long to wait before going back to the start screen. |
| **Colours & fonts** | Quick looks (Plum night, Cream, Midnight gold, Blush, Sunny, Mono), or your own accent, background, card, text and secondary-text colours. Font for buttons and text, and corner roundness. **Reset** all screens. |

Staff screens (settings, editors and the PIN pad) keep their own dark style, so they always stay readable whatever theme you choose.

---

## Guest downloads: choose how guests get their photos
Settings → **Sharing** → **Guest downloads (QR code)** → *How guests get their photos*:

| Option | How it works | Needs |
|---|---|---|
| **Online** | Each session uploads to your free Supabase account. Guests scan on any network and can download later at home. | Internet on the booth laptop (venue Wi-Fi, pocket Wi-Fi or a phone hotspot) |
| **Local Wi-Fi** | Phones download straight from the laptop. | Guests on the same Wi-Fi as the laptop; `LePetique.exe` running |
| **Off** | No QR code. | — |

In Online mode, if the internet drops, the booth keeps working. The QR code still shows, photos wait in a queue, and they upload automatically when the connection returns; the QR code then works. You can also force it: Settings → Sharing → **Upload waiting photos now**.

### One-time setup for Online mode (about 10 minutes, free)
1. Go to **supabase.com** and sign up. A card isn't needed for the free plan.
2. Click **New project**. Give it a name (for example *lepetique*), set a database password (save it somewhere), and choose a region near you (for example *Southeast Asia (Singapore)*). Wait a minute for it to start.
3. Open **Storage** in the left menu, then **New bucket**:
   - Name: `photobooth`
   - Turn on **Public bucket**
   - Optional: set the file size limit to 50 MB and the allowed MIME types to `image/jpeg, image/gif, video/mp4, video/webm` (leave out the video types and Scribble videos can't upload)
   - Click **Create**
4. Open **SQL Editor** in the left menu, paste the following, and click **Run**. It lets the booth add photos, but not list, change or delete them.
   ```sql
   create policy "Photobooth can upload"
   on storage.objects for insert
   to anon
   with check (bucket_id = 'photobooth');
   ```
5. Get your two values:
   - **Project URL**, which looks like `https://abcdefghijkl.supabase.co`. Click **Connect** at the top of the dashboard, or look under Project Settings → Data API.
   - **Publishable key**, which starts with `sb_publishable_`. It's under Project Settings → **API Keys**. If your project only shows an older `anon` key starting with `eyJ`, that works too.
6. In the booth: Settings → Sharing → **Online**. Paste the URL and key, leave the bucket as `photobooth`, and tap **Test connection**.
7. To double-check, turn off Wi-Fi on your phone and scan the test QR code using mobile data. You should see a small "OK" picture.

Each event's photos go in their own folder, named after your event unless you set **Event folder**. You can delete old events in Supabase under Storage → photobooth.

If the QR says **Upload delayed**, the booth keeps retrying every 20 seconds. The reason it failed is written in `LePetique.log` (lines starting with `cloud:`), for example a file larger than the bucket's size limit.

### One QR for the photo, live photo, GIF and video (guest page)
Supabase can only link to one file at a time, so for one QR that shows every version of a session you host a small guest page once. It's free, and nothing but that one page is stored there: the photos stay in Supabase.
1. Sign up at **github.com** (free).
2. Click **+** (top right) → **New repository**. Name it `photos`, choose **Public**, and click **Create repository**.
3. Click **uploading an existing file**, drag in the `guest-viewer\p` folder from the Le Petique folder (the guest page lives in a `p` folder so your own website, see *Your website on your own domain*, can use the main address), and click **Commit changes**. If GitHub drops the folder, use **Add file → Create new file**, type `p/index.html` as the name, paste the contents of `guest-viewer\p\index.html` and commit.
4. Open the repository's **Settings → Pages**. Under **Branch**, choose `main` and `/ (root)`, then click **Save**. After a minute the guest page is at `https://YOUR-GITHUB-NAME.github.io/photos/p/`.
5. In the booth: Settings → Sharing → Online → **Guest page address**, paste that address (with the `/p/` at the end).

From then on, every QR opens a page with the photo plus its live photo, GIF or video. The buttons suit the guest's phone:
- **iPhone:** **Save all to Photos** (and **Save … to Photos** under each one) opens the iPhone's menu, where one more tap on **Save Image** / **Save Video** puts it in Photos. **Post to Instagram or send** opens the same menu for Instagram, TikTok or WhatsApp. (iPhones don't let any web page save to Photos without that one menu tap.)
- **Android:** **Save all to gallery** (and **Save … to gallery** under each one) downloads the files. They show up straight away in Gallery or Google Photos, in the Downloads album.

The Wi-Fi guest page (local delivery) does the same on Android. On iPhone it can't open the share menu, because iPhones only allow that on secure `https://` pages, so it explains press-and-hold → **Save to Photos** instead. For one-tap saving on iPhones, use online delivery.
When you change `guest-viewer\p\index.html`, upload it to your `photos` repository again the same way (it replaces the old one). If a guest scans while the booth is still uploading, the page waits and fills in by itself. (Netlify or Cloudflare Pages work too: upload the `guest-viewer` folder.)

### Things to know about the free Supabase plan
- **1 GB of photo storage.** That's roughly 700–2,000 sessions, depending on the mix of photos and GIFs. Delete old event folders to free up space.
- **5 GB of downloads a month.**
- **Free projects pause after about a week without activity.** While a project is paused, download links stop working. Supabase emails you before it pauses. To bring the links back, open the dashboard, select the project, and click **Resume project**. If you need links to work forever with no pausing, the Pro plan removes this.
- **Privacy:** each photo's link is a random 10-character code, so it can't be guessed. Anyone who has a photo's link or QR code can view that photo, so treat links like you would a shared photo.

### Setup for Local Wi-Fi mode
Guests' phones must be on the same Wi-Fi as the laptop:
- The easiest way is Windows **Mobile hotspot** (Settings → Network & internet). Enter its name and password under *Guest Wi-Fi name* in the booth settings, and the results screen shows a "1. Join Wi-Fi" QR code before the photo QR code.
- Avoid hotel and venue guest Wi-Fi. It often blocks phones from reaching the laptop.
- To check it works, scan the test QR code in settings with your phone. You should see a tick saying your phone can reach the photobooth.

---

## Event analytics
A web page with your numbers: **total sessions, average session time, popular layouts, print volume, busiest hours, guest engagement** (QR codes shown, opened, saved; Save/Share taps; "Go again"), **drop-offs and failures** (guests who left, failed prints, delayed uploads), and **money**: package fees, print sales, media and other costs, profit, deposits and what is still owed, with a monthly chart. You can pick an event and date range, compare events side by side, and download CSV files.

**On the booth laptop:** Settings → Sharing → **Event analytics** → **Open analytics**. You are already past the staff PIN to be in Settings, so it opens with nothing to type. It needs no internet, and the figures are saved next to your photos in `LePetique Photos\analytics`. It closes by itself after 3 minutes without a touch, so it is never left open for guests. The laptop page (`/analytics`) works on the booth laptop only: a phone on the booth's Wi-Fi, guests included, is refused.

**From anywhere (online) for owners and managers:** with Online delivery set up, every session's figures are also sent to your Supabase project. Everyone signs in with **their own email and password**, so nobody shares a PIN and you can take one person's access away without affecting the others.

| | Owner | Manager |
|---|---|---|
| Stats, money, compare, CSV downloads | yes | yes |
| Online design editor | yes | yes |
| Add or edit events and prices | yes | view only |
| Remove sessions from the analytics | yes | no |
| Delete online photos | yes | no |
| Add and remove people | yes | no |

One-time setup (about 10 minutes):
1. In Supabase: **Authentication → Sign In / Providers**: make sure **Email** is on and turn **Allow new users to sign up OFF**, so only people you add can sign in.
2. **Authentication → URL Configuration:** set the **Site URL** to the address of your analytics page (`https://…/analytics.html`, next to the guest page), so invite and password-reset emails open it.
3. **Authentication → Users → Add user:** create your own account (email and password, tick *Auto Confirm User*).
4. Open `guest-viewer\analytics.sql`, and at the very end replace `owner@example.com` with your email. Then paste the **whole file** into **SQL Editor** and click **Run**. This switches off the old shared PIN: it stops working online.
5. Upload `guest-viewer\analytics.html` (and `editor.html`) to the same free host as the guest page, replacing the old ones.
6. Open the analytics page, enter the Supabase project URL and publishable key once, then sign in with your email and password.

**Adding a manager or another owner:** create their account in Supabase (**Authentication → Users → Add user**, or **Invite user**, which emails them a link to choose their own password), then on the analytics page open **People**, type their email, pick **Manager** or **Owner** and press **Give access**. Send them the page address, the project URL and the publishable key privately. **Remove access** locks them out straight away.

**Forgot your password?** Use *Forgot your password?* on the sign-in page, or reset it from **Authentication → Users** in Supabase.

Good to know:
- **Events & money:** the event name you type there must match the booth's *Event name* so prints are counted automatically. Each event has a **Type**:
  - **Private event** (a package price): income = package price + add-ons + prints beyond the "included" number × price per extra print.
  - **Session-based:** income = sessions × price per session + extra prints × price per extra print (counted per session: copies above the prints included in each session) + add-ons + a base fee, if any.
  - **Add-ons** (extra hour, props, backdrop…) are listed per event with a price, and add to the income. Costs = prints × media cost + your other costs. Events saved before this count as private events. Your prices live where you enter them: on the laptop page they are saved on the laptop, on the online page in Supabase, so use one of them for money.
- A "session" counts when a guest takes their first photo. Guests who tap a mode and walk away show under *Left before shooting*.
- Guest opens and saves are counted from the **Wi-Fi** guest page. Online (Supabase) guest pages don't report back, so those show only "QR code shown".
- The online page shows nothing without a sign-in, and the booth's key can only add records, not read them. Managers are held back by the database itself, not just hidden buttons.
- **Event in use:** the booth tells the analytics which saved event it is using (when it starts, when you switch events or rename it). The page opens on that event, marked "(in use now)".
- **Online photos tab (online page only):** shows each event's folder in your Supabase bucket with its number of files, size and dates, and lets you **delete an event's photos** or **everything older than N days** (default 60), each after a confirmation that says how many files and how many MB. Guests' links to deleted photos stop working, and deleted files can't be recovered; the photos on the booth laptop are never touched, and the online editor's design copies (`_designs`) are left alone. Only owners see this tab, and it deletes with the owner's own sign-in: no secret key is pasted anywhere, and the booth's publishable key is deliberately not allowed to delete. Nothing is deleted automatically.
- **Sessions tab:** lists the sessions of the chosen event and date range, with a **Remove** button per session and tick boxes to remove several at once (owners only). A session you delete in the booth's gallery stays in the analytics until an owner removes it here, so the booth isn't flooded; removing here never touches the booth's photos. Online, run the updated `analytics.sql` once (it adds `stats_remove`).

## Your website on your own domain
`guest-viewer\index.html` is a public website for your business: a top banner, **Packages** with prices, a **Gallery**, **Reviews**, **Questions** (FAQ), an **About** story, a **contact form** and your **social links**. You change all of it yourself in the **Website editor**, with a live preview, and **Save** updates the site straight away: nothing to re-upload.

| Address | What |
|---|---|
| `yourdomain/` | The public website |
| `yourdomain/p/` | The guest photo page (what the booth's QR codes open) |
| `yourdomain/site-editor.html` | The website editor (owners only) |
| `yourdomain/analytics.html`, `editor.html` | Analytics and the design editor, as before. They are not in the website's menu and are hidden from search engines. Only signed-in staff can see anything. |

**Set it up (about 30 minutes, plus waiting for the domain):**
1. **Point your domain at GitHub.** At the company you bought the domain from, open its DNS settings and add four **A** records for the domain itself (host `@`) with these values: `185.199.108.153`, `185.199.109.153`, `185.199.110.153` and `185.199.111.153`. Add one **CNAME** record for `www` pointing to `YOUR-GITHUB-NAME.github.io`. (Delete any other `A` or `CNAME` records for `@` and `www`, such as a "parked page".)
2. In your `photos` repository on GitHub: **Settings → Pages → Custom domain**, type your domain and click **Save**. When GitHub says it is ready (it can take up to a day), tick **Enforce HTTPS**.
3. **Run the updated `guest-viewer\analytics.sql`** in Supabase (SQL Editor, paste the **whole file**, **Run**). It adds the website's tables, the pictures folder and the contact form. It is safe to run again. Keep your email in the last lines, as before.
4. In Supabase: **Authentication → URL Configuration**: change the **Site URL** to `https://yourdomain/analytics.html`, so invite and password-reset emails open the new address.
5. **Upload to your `photos` repository** (drag the files in, **Commit changes**): the new `guest-viewer\index.html` (the website; it replaces the old guest page there), `guest-viewer\site-editor.html`, the new `guest-viewer\analytics.html`, and the guest page, now at `guest-viewer\p\index.html`. For the last one, use **Add file → Create new file**, type `p/index.html` as the name, and paste the file's contents (or drag the `p` folder in).
6. Open `yourdomain/site-editor.html` and sign in (the same email and password as analytics). Press **Download config.js** and upload that file to the repository too: it only holds your project address and public key, and the website needs it to read your changes and to send contact messages. Once it is uploaded, the website editor, analytics and the design editor only ask for email and password: nobody types the project URL or key again.
7. In the booth: Settings → Sharing → Online → **Guest page address**: `https://yourdomain/p/`. New QR codes use it. **Old QR codes keep working**: the old address forwards to the new one.

**Using the editor:** the tabs are **Look** (colours, fonts, name, logo), **Top banner**, **About**, **Packages**, **Gallery**, **Reviews**, **Questions**, **Contact & socials**, **QR codes**, **Sections** (switch sections on or off and change their order), **Search & sharing** (what Google and link previews show) and **Inquiries** (messages from your contact form, with a dot when something is new). Pictures are shrunk automatically before they are added. Only owners can save; managers can't.
- **Drag to reorder:** every item in Packages, Gallery, Reviews, Questions and Sections has a **⠿ Drag** handle: hold it and move the item up or down (or across, in the gallery), then let go. It works with a mouse and with a finger. The ↑ ↓ buttons still work for small moves. The top banner always stays first.
- **Animations** (Look tab): choose how sections appear as visitors scroll (**fade in**, **slide up**, **slide in from the sides**, or none), the speed, whether the top banner's words slide in when the page opens, a slow zoom on the banner picture, and hover effects (cards lift, gallery pictures zoom, buttons glow). **Replay in preview** shows it again. Anyone whose phone or computer is set to "reduce motion" sees none of it, whatever you choose.
- **Gallery slideshow:** in the Gallery tab, **Show as → Slideshow** turns the pictures into a sliding slideshow (2 to 10 seconds a picture, arrows, dots, swipe on phones; it pauses when someone points at it). Tapping a picture still opens it large.
- **Socials QR codes:** the **QR codes** tab adds a "Scan to follow us" section with one QR code per link you filled in under Contact & socials (Instagram, TikTok, Facebook, YouTube, WhatsApp, email), each with an **Open** button for people already on their phone. Untick any you do not want, change the heading and words, and keep dark squares on a light background so phones can scan them (the editor warns you if the colours are too alike). It appears after the contact form; drag it wherever you like in **Sections**. The codes are made in the visitor's browser: nothing is sent to anyone.
- After changing the editor or the site files, upload the new `index.html` and `site-editor.html` to your `photos` repository (the content you edit in the editor is saved in Supabase, so only these two files need uploading, once). Browsers keep website pages for about 10 minutes, so after an upload press **Ctrl+F5**, and press **↻ Reload preview** in the editor: it always fetches the newest version of the site. If the preview or the site still looks old (for example the package buttons say "Enquire" instead of "Inquire"), it is showing a kept copy, not a problem with your saved content.

Things to know:
- **Licensed fonts such as Slight can't be used on the website**: they stay in the booth. The website uses free web fonts, chosen in the **Look** tab.
- The gallery only shows pictures **you** add. Nothing from the booth or from guests is shown automatically.
- Without `config.js` the site still shows, with sample text, and the contact form opens the visitor's email app.
- Contact messages are limited (5 per person per hour) to keep spam down.
- Everything you type in the editor is kept in your Supabase project, not in this folder, so it isn't in Git.

## Online design editor (change designs from anywhere)
`guest-viewer\editor.html` is the booth's own template editor and booth-screen designer as a web page. You change an event's print designs and screens from any computer, and the booth picks the changes up.
1. Set up the sign-ins described under *Event analytics* above (the same `guest-viewer\analytics.sql` also adds the design tables and functions).
2. Upload `guest-viewer\editor.html` to the same free host as the guest page and analytics (it is rebuilt by `web\build.ps1`; it is a copy of the booth page, about 400 KB).
3. In the booth, set up Online delivery (Settings → Sharing). Within a minute the booth uploads each saved event's designs and pictures (to the `_designs` folder of your bucket).
4. Open the online analytics page and press **Design editor** (top right). The editor opens already signed in as you; **← Analytics** in its top bar takes you back. (Opened on its own, the editor asks for the Supabase URL, publishable key, and your email and password; the bucket is optional because the booth tells the editor which one it uses.) Owners and managers can both use the editor. Pick the event, edit, and press **Save to booth**.
5. The booth takes the new version within about a minute. For the event in use, it waits until no guest or settings screen is open. Other saved events update in the background. The booth shows "Designs updated from the web".

Good to know:
- **Which booth:** give each booth a name in Settings → Booth → **Booth name**. The editor lists each event with its booth, shows "Updates: <booth name>" in its top bar, and says which booth takes your save. Run the updated `analytics.sql` once for this.
- It edits **designs only** (print templates and booth screens, with their pictures, stickers and custom fonts). Camera, printers, delivery and the PIN stay on the booth.
- When the web version replaces designs the booth changed since it last took a web version, the booth keeps its own copy as a saved event called "… (before web edit)". Template pictures replaced under the same name are not kept in that copy.
- If the booth saves a newer version than the web one, the newest wins. Switch events or reload to see the latest.
- Only a signed-in owner or manager can save a web version. The booth's key can only add booth versions, so a leaked key can't change your designs. Anyone with the booth's key can read the latest web version, as they can already read the public photos folder.
- Pictures are named after their content, so each is uploaded once, and Supabase keeps the last 10 versions of each event.
- If your bucket only allows some file types (for example JPEG and MP4), the booth sends PNG, GIF and font files labelled as JPEG; the editor reads them back by content. Clearing the bucket's *Allowed MIME types* box also works.

---

## Everything else
- **Modes:** photo strip (fully customisable, 1–8 photos, 4×6, 5×7, 6×8, square or custom sizes), animated GIF, boomerang, Scribble and Video message.
- **Capture:** countdown with beeps, shutter sound and flash, and 7 live filters. **Test the countdown** (Settings → Camera, and Settings → Modes) shows the camera screen and runs the real countdown, flash and sound without taking a photo, then returns to Settings.
- **Printing:** each template has its own Paper size setting; 2×6 strips print two per 4×6 sheet (DNP printers cut them for you), everything else prints on its own paper size.
- **Gallery:** every session is kept on the laptop and in `LePetique Photos`.
- **Kiosk use:** the booth returns to the start screen after an idle period. While a QR code is showing, the results screen stays up for at least 75 seconds.
- **Keyboard and USB buttons:** Space or Enter starts, 1–5 picks a mode, Esc goes back.
- **Advanced options:** `LePetique.exe -port 9000` changes the port, and `-dir "D:\Event Photos"` changes the photos folder.
